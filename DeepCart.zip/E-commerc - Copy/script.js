
const click2 = document.querySelector("#click2");
click2.onclick = function () {
  const  navBar = document.querySelector(".flex");
    navBar.classList.toggle("active")

}